#pragma once


#define MAX_CULTURE 12
#define MAX_MSC 30
#define MAX_DESIGN 12

namespace EZABEEK_Client{

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Form3�� ���� ����Դϴ�.
	/// </summary>
	public ref class Form3 : public System::Windows::Forms::Form
	{
		public: static int result_culture;
		public: static int result_msc;
	private: System::Windows::Forms::RichTextBox^  richTextBox1;
	public: 
	private: System::Windows::Forms::RichTextBox^  richTextBox2;
	private: System::Windows::Forms::RichTextBox^  richTextBox3;
	private: System::Windows::Forms::TextBox^  textBox1;
	public: static int result_design;
	
	public:
		Form3(void)
		{
			InitializeComponent();
			//
			//TODO: ������ �ڵ带 ���⿡ �߰��մϴ�.
			//
		}

	protected:
		/// <summary>
		/// ��� ���� ��� ���ҽ��� �����մϴ�.
		/// </summary>
		~Form3()
		{
			if (components)
			{
				delete components;
			}
		}

	protected: 

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::CheckBox^  checkBox1;
	private: System::Windows::Forms::CheckBox^  checkBox2;
	private: System::Windows::Forms::CheckBox^  checkBox3;
	private: System::Windows::Forms::CheckBox^  checkBox4;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::CheckBox^  checkBox13;
	private: System::Windows::Forms::CheckBox^  checkBox14;
	private: System::Windows::Forms::CheckBox^  checkBox9;
	private: System::Windows::Forms::CheckBox^  checkBox10;
	private: System::Windows::Forms::CheckBox^  checkBox11;
	private: System::Windows::Forms::CheckBox^  checkBox12;
	private: System::Windows::Forms::CheckBox^  checkBox5;
	private: System::Windows::Forms::CheckBox^  checkBox6;
	private: System::Windows::Forms::CheckBox^  checkBox7;
	private: System::Windows::Forms::CheckBox^  checkBox8;
	private: System::Windows::Forms::GroupBox^  groupBox3;
	private: System::Windows::Forms::CheckBox^  checkBox19;
	private: System::Windows::Forms::CheckBox^  checkBox15;
	private: System::Windows::Forms::CheckBox^  checkBox16;
	private: System::Windows::Forms::CheckBox^  checkBox17;
	private: System::Windows::Forms::CheckBox^  checkBox18;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::CheckBox^  checkBox20;
	private: System::Windows::Forms::CheckBox^  checkBox21;
	private: System::Windows::Forms::CheckBox^  checkBox22;
	private: System::Windows::Forms::CheckBox^  checkBox23;
	private: System::Windows::Forms::Label^  label_title;
	private: System::Windows::Forms::Label^  label_culture;
	private: System::Windows::Forms::Label^  label_design;
	private: System::Windows::Forms::Label^  label_msc;





	protected: 

	private:
		/// <summary>
		/// �ʼ� �����̳� �����Դϴ�.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox4 = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->checkBox13 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox14 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox9 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox10 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox11 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox12 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox5 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox6 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox7 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox8 = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->checkBox20 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox21 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox22 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox23 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox19 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox15 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox16 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox17 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox18 = (gcnew System::Windows::Forms::CheckBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label_title = (gcnew System::Windows::Forms::Label());
			this->label_culture = (gcnew System::Windows::Forms::Label());
			this->label_design = (gcnew System::Windows::Forms::Label());
			this->label_msc = (gcnew System::Windows::Forms::Label());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox2 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox3 = (gcnew System::Windows::Forms::RichTextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button1->Location = System::Drawing::Point(649, 13);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(101, 49);
			this->button1->TabIndex = 7;
			this->button1->Text = L"���Ȯ��";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form3::button1_Click);
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Location = System::Drawing::Point(20, 42);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(95, 22);
			this->checkBox1->TabIndex = 8;
			this->checkBox1->Text = L"���ʱ۾���";
			this->checkBox1->UseVisualStyleBackColor = true;
			// 
			// checkBox2
			// 
			this->checkBox2->AutoSize = true;
			this->checkBox2->Location = System::Drawing::Point(20, 78);
			this->checkBox2->Name = L"checkBox2";
			this->checkBox2->Size = System::Drawing::Size(108, 22);
			this->checkBox2->TabIndex = 9;
			this->checkBox2->Text = L"�����ΰ�����";
			this->checkBox2->UseVisualStyleBackColor = true;
			// 
			// checkBox3
			// 
			this->checkBox3->AutoSize = true;
			this->checkBox3->Location = System::Drawing::Point(20, 112);
			this->checkBox3->Name = L"checkBox3";
			this->checkBox3->Size = System::Drawing::Size(121, 22);
			this->checkBox3->TabIndex = 10;
			this->checkBox3->Text = L"�����ΰ��⵶��";
			this->checkBox3->UseVisualStyleBackColor = true;
			// 
			// checkBox4
			// 
			this->checkBox4->AutoSize = true;
			this->checkBox4->Location = System::Drawing::Point(20, 148);
			this->checkBox4->Name = L"checkBox4";
			this->checkBox4->Size = System::Drawing::Size(121, 22);
			this->checkBox4->TabIndex = 11;
			this->checkBox4->Text = L"������������";
			this->checkBox4->UseVisualStyleBackColor = true;
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->checkBox1);
			this->groupBox1->Controls->Add(this->checkBox4);
			this->groupBox1->Controls->Add(this->checkBox2);
			this->groupBox1->Controls->Add(this->checkBox3);
			this->groupBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->groupBox1->Location = System::Drawing::Point(12, 75);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(158, 219);
			this->groupBox1->TabIndex = 12;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"��������";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->checkBox13);
			this->groupBox2->Controls->Add(this->checkBox14);
			this->groupBox2->Controls->Add(this->checkBox9);
			this->groupBox2->Controls->Add(this->checkBox10);
			this->groupBox2->Controls->Add(this->checkBox11);
			this->groupBox2->Controls->Add(this->checkBox12);
			this->groupBox2->Controls->Add(this->checkBox5);
			this->groupBox2->Controls->Add(this->checkBox6);
			this->groupBox2->Controls->Add(this->checkBox7);
			this->groupBox2->Controls->Add(this->checkBox8);
			this->groupBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->groupBox2->Location = System::Drawing::Point(176, 75);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(318, 219);
			this->groupBox2->TabIndex = 13;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"MSC";
			// 
			// checkBox13
			// 
			this->checkBox13->AutoSize = true;
			this->checkBox13->Location = System::Drawing::Point(159, 182);
			this->checkBox13->Name = L"checkBox13";
			this->checkBox13->Size = System::Drawing::Size(147, 22);
			this->checkBox13->TabIndex = 17;
			this->checkBox13->Tag = L"";
			this->checkBox13->Text = L"Ȯ�����������μ���";
			this->checkBox13->UseVisualStyleBackColor = true;
			// 
			// checkBox14
			// 
			this->checkBox14->AutoSize = true;
			this->checkBox14->Location = System::Drawing::Point(20, 182);
			this->checkBox14->Name = L"checkBox14";
			this->checkBox14->Size = System::Drawing::Size(95, 22);
			this->checkBox14->TabIndex = 16;
			this->checkBox14->Text = L"���л�����";
			this->checkBox14->UseVisualStyleBackColor = true;
			// 
			// checkBox9
			// 
			this->checkBox9->AutoSize = true;
			this->checkBox9->Location = System::Drawing::Point(159, 42);
			this->checkBox9->Name = L"checkBox9";
			this->checkBox9->Size = System::Drawing::Size(103, 22);
			this->checkBox9->TabIndex = 12;
			this->checkBox9->Text = L"���й�����ll";
			this->checkBox9->UseVisualStyleBackColor = true;
			// 
			// checkBox10
			// 
			this->checkBox10->AutoSize = true;
			this->checkBox10->Location = System::Drawing::Point(159, 148);
			this->checkBox10->Name = L"checkBox10";
			this->checkBox10->Size = System::Drawing::Size(147, 22);
			this->checkBox10->TabIndex = 15;
			this->checkBox10->Text = L"��Ű��������Ѽ���";
			this->checkBox10->UseVisualStyleBackColor = true;
			// 
			// checkBox11
			// 
			this->checkBox11->AutoSize = true;
			this->checkBox11->Location = System::Drawing::Point(159, 78);
			this->checkBox11->Name = L"checkBox11";
			this->checkBox11->Size = System::Drawing::Size(129, 22);
			this->checkBox11->TabIndex = 13;
			this->checkBox11->Text = L"���α׷��־��ll";
			this->checkBox11->UseVisualStyleBackColor = true;
			// 
			// checkBox12
			// 
			this->checkBox12->AutoSize = true;
			this->checkBox12->Location = System::Drawing::Point(159, 112);
			this->checkBox12->Name = L"checkBox12";
			this->checkBox12->Size = System::Drawing::Size(95, 22);
			this->checkBox12->TabIndex = 14;
			this->checkBox12->Text = L"���������";
			this->checkBox12->UseVisualStyleBackColor = true;
			// 
			// checkBox5
			// 
			this->checkBox5->AutoSize = true;
			this->checkBox5->Location = System::Drawing::Point(20, 42);
			this->checkBox5->Name = L"checkBox5";
			this->checkBox5->Size = System::Drawing::Size(82, 22);
			this->checkBox5->TabIndex = 8;
			this->checkBox5->Text = L"���м���";
			this->checkBox5->UseVisualStyleBackColor = true;
			// 
			// checkBox6
			// 
			this->checkBox6->AutoSize = true;
			this->checkBox6->Location = System::Drawing::Point(20, 148);
			this->checkBox6->Name = L"checkBox6";
			this->checkBox6->Size = System::Drawing::Size(95, 22);
			this->checkBox6->TabIndex = 11;
			this->checkBox6->Text = L"�̺й�����";
			this->checkBox6->UseVisualStyleBackColor = true;
			// 
			// checkBox7
			// 
			this->checkBox7->AutoSize = true;
			this->checkBox7->Location = System::Drawing::Point(20, 78);
			this->checkBox7->Name = L"checkBox7";
			this->checkBox7->Size = System::Drawing::Size(99, 22);
			this->checkBox7->TabIndex = 9;
			this->checkBox7->Text = L"���й�����l";
			this->checkBox7->UseVisualStyleBackColor = true;
			// 
			// checkBox8
			// 
			this->checkBox8->AutoSize = true;
			this->checkBox8->Location = System::Drawing::Point(20, 112);
			this->checkBox8->Name = L"checkBox8";
			this->checkBox8->Size = System::Drawing::Size(125, 22);
			this->checkBox8->TabIndex = 10;
			this->checkBox8->Text = L"���α׷��־��l";
			this->checkBox8->UseVisualStyleBackColor = true;
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->checkBox20);
			this->groupBox3->Controls->Add(this->checkBox21);
			this->groupBox3->Controls->Add(this->checkBox22);
			this->groupBox3->Controls->Add(this->checkBox23);
			this->groupBox3->Controls->Add(this->checkBox19);
			this->groupBox3->Controls->Add(this->checkBox15);
			this->groupBox3->Controls->Add(this->checkBox16);
			this->groupBox3->Controls->Add(this->checkBox17);
			this->groupBox3->Controls->Add(this->checkBox18);
			this->groupBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->groupBox3->Location = System::Drawing::Point(500, 75);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(306, 219);
			this->groupBox3->TabIndex = 13;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"�������";
			// 
			// checkBox20
			// 
			this->checkBox20->AutoSize = true;
			this->checkBox20->Location = System::Drawing::Point(158, 42);
			this->checkBox20->Name = L"checkBox20";
			this->checkBox20->Size = System::Drawing::Size(121, 22);
			this->checkBox20->TabIndex = 13;
			this->checkBox20->Text = L"��ǻ����Žǽ�";
			this->checkBox20->UseVisualStyleBackColor = true;
			this->checkBox20->CheckedChanged += gcnew System::EventHandler(this, &Form3::checkBox20_CheckedChanged);
			// 
			// checkBox21
			// 
			this->checkBox21->AutoSize = true;
			this->checkBox21->Location = System::Drawing::Point(158, 148);
			this->checkBox21->Name = L"checkBox21";
			this->checkBox21->Size = System::Drawing::Size(134, 22);
			this->checkBox21->TabIndex = 16;
			this->checkBox21->Text = L"�����нý��ۼ���";
			this->checkBox21->UseVisualStyleBackColor = true;
			// 
			// checkBox22
			// 
			this->checkBox22->AutoSize = true;
			this->checkBox22->Location = System::Drawing::Point(158, 78);
			this->checkBox22->Name = L"checkBox22";
			this->checkBox22->Size = System::Drawing::Size(134, 22);
			this->checkBox22->TabIndex = 14;
			this->checkBox22->Text = L"��������α׷���";
			this->checkBox22->UseVisualStyleBackColor = true;
			// 
			// checkBox23
			// 
			this->checkBox23->AutoSize = true;
			this->checkBox23->Location = System::Drawing::Point(158, 112);
			this->checkBox23->Name = L"checkBox23";
			this->checkBox23->Size = System::Drawing::Size(108, 22);
			this->checkBox23->TabIndex = 15;
			this->checkBox23->Text = L"��Ű��нǽ�";
			this->checkBox23->UseVisualStyleBackColor = true;
			// 
			// checkBox19
			// 
			this->checkBox19->AutoSize = true;
			this->checkBox19->Location = System::Drawing::Point(20, 182);
			this->checkBox19->Name = L"checkBox19";
			this->checkBox19->Size = System::Drawing::Size(82, 22);
			this->checkBox19->TabIndex = 12;
			this->checkBox19->Text = L"���ռ���";
			this->checkBox19->UseVisualStyleBackColor = true;
			// 
			// checkBox15
			// 
			this->checkBox15->AutoSize = true;
			this->checkBox15->Location = System::Drawing::Point(20, 42);
			this->checkBox15->Name = L"checkBox15";
			this->checkBox15->Size = System::Drawing::Size(108, 22);
			this->checkBox15->TabIndex = 8;
			this->checkBox15->Text = L"���м����Թ�";
			this->checkBox15->UseVisualStyleBackColor = true;
			// 
			// checkBox16
			// 
			this->checkBox16->AutoSize = true;
			this->checkBox16->Location = System::Drawing::Point(20, 148);
			this->checkBox16->Name = L"checkBox16";
			this->checkBox16->Size = System::Drawing::Size(108, 22);
			this->checkBox16->TabIndex = 11;
			this->checkBox16->Text = L"����ȸ�μ���";
			this->checkBox16->UseVisualStyleBackColor = true;
			// 
			// checkBox17
			// 
			this->checkBox17->AutoSize = true;
			this->checkBox17->Location = System::Drawing::Point(20, 78);
			this->checkBox17->Name = L"checkBox17";
			this->checkBox17->Size = System::Drawing::Size(121, 22);
			this->checkBox17->TabIndex = 9;
			this->checkBox17->Text = L"���α׷��ּ���";
			this->checkBox17->UseVisualStyleBackColor = true;
			this->checkBox17->CheckedChanged += gcnew System::EventHandler(this, &Form3::checkBox17_CheckedChanged);
			// 
			// checkBox18
			// 
			this->checkBox18->AutoSize = true;
			this->checkBox18->Location = System::Drawing::Point(20, 112);
			this->checkBox18->Name = L"checkBox18";
			this->checkBox18->Size = System::Drawing::Size(108, 22);
			this->checkBox18->TabIndex = 10;
			this->checkBox18->Text = L"����ȸ�μ���";
			this->checkBox18->UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label1->ForeColor = System::Drawing::Color::CadetBlue;
			this->label1->Location = System::Drawing::Point(162, 27);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(350, 20);
			this->label1->TabIndex = 14;
			this->label1->Text = L"�����Ͻ� ������ üũ�� �ֽð� ���Ȯ�� ��ư�� �����ּ���.";
			// 
			// label_title
			// 
			this->label_title->AutoSize = true;
			this->label_title->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label_title->Location = System::Drawing::Point(337, 346);
			this->label_title->Name = L"label_title";
			this->label_title->Size = System::Drawing::Size(160, 24);
			this->label_title->TabIndex = 15;
			this->label_title->Text = L"����� ���� ������...";
			// 
			// label_culture
			// 
			this->label_culture->AutoSize = true;
			this->label_culture->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label_culture->ForeColor = System::Drawing::Color::Black;
			this->label_culture->Location = System::Drawing::Point(246, 390);
			this->label_culture->Name = L"label_culture";
			this->label_culture->Size = System::Drawing::Size(71, 17);
			this->label_culture->TabIndex = 16;
			this->label_culture->Text = L"�������� : ";
			// 
			// label_design
			// 
			this->label_design->AutoSize = true;
			this->label_design->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label_design->ForeColor = System::Drawing::Color::Black;
			this->label_design->Location = System::Drawing::Point(486, 390);
			this->label_design->Name = L"label_design";
			this->label_design->Size = System::Drawing::Size(47, 17);
			this->label_design->TabIndex = 18;
			this->label_design->Text = L"���� : ";
			// 
			// label_msc
			// 
			this->label_msc->AutoSize = true;
			this->label_msc->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label_msc->ForeColor = System::Drawing::Color::Black;
			this->label_msc->Location = System::Drawing::Point(368, 390);
			this->label_msc->Name = L"label_msc";
			this->label_msc->Size = System::Drawing::Size(55, 17);
			this->label_msc->TabIndex = 17;
			this->label_msc->Text = L"MSC : ";
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(313, 383);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(49, 33);
			this->richTextBox1->TabIndex = 23;
			this->richTextBox1->Text = L"";
			// 
			// richTextBox2
			// 
			this->richTextBox2->Location = System::Drawing::Point(419, 381);
			this->richTextBox2->Name = L"richTextBox2";
			this->richTextBox2->Size = System::Drawing::Size(49, 33);
			this->richTextBox2->TabIndex = 24;
			this->richTextBox2->Text = L"";
			// 
			// richTextBox3
			// 
			this->richTextBox3->Location = System::Drawing::Point(533, 381);
			this->richTextBox3->Name = L"richTextBox3";
			this->richTextBox3->Size = System::Drawing::Size(49, 33);
			this->richTextBox3->TabIndex = 25;
			this->richTextBox3->Text = L"";
			// 
			// textBox1
			// 
			this->textBox1->BackColor = System::Drawing::SystemColors::Control;
			this->textBox1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->textBox1->Font = (gcnew System::Drawing::Font(L"����", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->textBox1->ForeColor = System::Drawing::Color::Red;
			this->textBox1->Location = System::Drawing::Point(33, 310);
			this->textBox1->Multiline = true;
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(761, 31);
			this->textBox1->TabIndex = 26;
			this->textBox1->Text = L"* �۹��� ���->���� �۾���, �̾߱�� ����1->�����ΰ� �⵶��, �̾߱�� ����2->�����ΰ� ���� ���� ����Ǿ����� ���������̼������� �����⵵ " 
				L"�������� ����˴ϴ�.";
			// 
			// Form3
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(821, 427);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->richTextBox3);
			this->Controls->Add(this->richTextBox2);
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->label_culture);
			this->Controls->Add(this->label_design);
			this->Controls->Add(this->label_msc);
			this->Controls->Add(this->label_title);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->button1);
			this->Name = L"Form3";
			this->Text = L"EZ Abeek Program Client";
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void groupBox1_Enter(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void radioButton8_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void checkBox20_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			int sum_culture = 0;
			int sum_msc = 0;
			int sum_design = 0;

			richTextBox1->Text = "";
			richTextBox2->Text = "";
			richTextBox3->Text = "";

		if (this->checkBox1->Checked.Equals(true))
			sum_culture += 3;
		if (this->checkBox2->Checked.Equals(true))
			sum_culture += 3;
		if (this->checkBox3->Checked.Equals(true))
			sum_culture += 3;
		if (this->checkBox4->Checked.Equals(true))
			sum_culture += 3;

		if (this->checkBox5->Checked.Equals(true))
			sum_msc += 3;
		if (this->checkBox6->Checked.Equals(true))
			sum_msc += 3;
		if (this->checkBox7->Checked.Equals(true))
			sum_msc += 3;
		if (this->checkBox8->Checked.Equals(true))
			sum_msc += 3;
		if (this->checkBox9->Checked.Equals(true))
			sum_msc += 3;
		if (this->checkBox10->Checked.Equals(true))
			sum_msc += 3;
		if (this->checkBox11->Checked.Equals(true))
			sum_msc += 3;
		if (this->checkBox12->Checked.Equals(true))
			sum_msc += 3;
		if (this->checkBox13->Checked.Equals(true))
			sum_msc += 3;
		if (this->checkBox14->Checked.Equals(true))
			sum_msc += 3;

		if (this->checkBox15->Checked.Equals(true))
			sum_design += 3;
		if (this->checkBox16->Checked.Equals(true))
			sum_design += 2;
		if (this->checkBox17->Checked.Equals(true))
			sum_design += 2; 
		if (this->checkBox18->Checked.Equals(true))
			sum_design += 2;
		if (this->checkBox19->Checked.Equals(true))
			sum_design += 3;
		if (this->checkBox20->Checked.Equals(true))
			sum_design += 1;
		if (this->checkBox21->Checked.Equals(true))
			sum_design += 1;
		if (this->checkBox22->Checked.Equals(true))
			sum_design += 1;
		if (this->checkBox23->Checked.Equals(true))
			sum_design += 1;

		result_culture = (MAX_CULTURE - sum_culture);
		result_msc = (MAX_MSC - sum_msc);
		result_design = (MAX_DESIGN - sum_design);

		richTextBox1->AppendText(result_culture.ToString());
		richTextBox2->AppendText(result_msc.ToString());
		richTextBox3->AppendText(result_design.ToString());		
		 }
private: System::Void button_return_Click(System::Object^  sender, System::EventArgs^  e) {
			 
		 }
private: System::Void checkBox17_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
