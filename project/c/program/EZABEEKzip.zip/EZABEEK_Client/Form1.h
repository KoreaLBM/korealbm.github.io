#pragma endregion
#include "stdAfx.h"
#include "Form2.h"
#include "Form4.h"
#include "Form5.h"
#include "Form10.h"

namespace EZABEEK_Client {


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Net;
    using namespace System::Net::Sockets;
    using namespace System::Runtime::Serialization;
    using namespace System::Runtime::Serialization::Formatters::Binary;
    using namespace System::Runtime::Serialization::Formatters;
    using namespace System::Threading;
	using namespace FormatterText;
	using namespace System::IO;

	/// <summary>
	/// Form1�� ���� ����Դϴ�.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: ������ �ڵ带 ���⿡ �߰��մϴ�.
			//
			CheckForIllegalCrossThreadCalls = false;
		}

	protected:
		/// <summary>
		/// ��� ���� ��� ���ҽ��� �����մϴ�.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  textBox1;
	protected: 
	private: System::Windows::Forms::Button^  button1;


	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::FontDialog^  fontDialog1;
	private: System::Windows::Forms::ColorDialog^  colorDialog1;
	private: System::ComponentModel::BackgroundWorker^  backgroundWorker1;
	private: System::Windows::Forms::Button^  frm1_btn1;
	private: System::Windows::Forms::Button^  frm1_btn2;
	private: System::Windows::Forms::Button^  frm1_btn3;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::LinkLabel^  linkLabel1;
	private: System::Windows::Forms::LinkLabel^  linkLabel2;
	private: System::Windows::Forms::RichTextBox^  richTextBox1;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::Label^  label3;

	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Label^  label4;







	private:
		/// <summary>
		/// �ʼ� �����̳� �����Դϴ�.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		void InitializeComponent(void)
		{
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->fontDialog1 = (gcnew System::Windows::Forms::FontDialog());
			this->colorDialog1 = (gcnew System::Windows::Forms::ColorDialog());
			this->backgroundWorker1 = (gcnew System::ComponentModel::BackgroundWorker());
			this->frm1_btn1 = (gcnew System::Windows::Forms::Button());
			this->frm1_btn2 = (gcnew System::Windows::Forms::Button());
			this->frm1_btn3 = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->linkLabel1 = (gcnew System::Windows::Forms::LinkLabel());
			this->linkLabel2 = (gcnew System::Windows::Forms::LinkLabel());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->SuspendLayout();
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(12, 91);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(320, 25);
			this->textBox1->TabIndex = 0;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button1->Location = System::Drawing::Point(338, 91);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 25);
			this->button1->TabIndex = 2;
			this->button1->Text = L"����";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(45, 228);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(266, 24);
			this->textBox2->TabIndex = 5;
			this->textBox2->TextChanged += gcnew System::EventHandler(this, &Form1::textBox2_TextChanged);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(326, 228);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 6;
			this->button2->Text = L"����";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// backgroundWorker1
			// 
			this->backgroundWorker1->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker1_DoWork);
			// 
			// frm1_btn1
			// 
			this->frm1_btn1->Location = System::Drawing::Point(16, 34);
			this->frm1_btn1->Name = L"frm1_btn1";
			this->frm1_btn1->Size = System::Drawing::Size(195, 50);
			this->frm1_btn1->TabIndex = 7;
			this->frm1_btn1->Text = L"��������Ȯ��";
			this->frm1_btn1->UseVisualStyleBackColor = true;
			this->frm1_btn1->Click += gcnew System::EventHandler(this, &Form1::frm1_btn1_Click);
			// 
			// frm1_btn2
			// 
			this->frm1_btn2->Location = System::Drawing::Point(16, 115);
			this->frm1_btn2->Name = L"frm1_btn2";
			this->frm1_btn2->Size = System::Drawing::Size(195, 50);
			this->frm1_btn2->TabIndex = 8;
			this->frm1_btn2->Text = L"�̼�ü��/���ļ�����Ȯ��";
			this->frm1_btn2->UseVisualStyleBackColor = true;
			this->frm1_btn2->Click += gcnew System::EventHandler(this, &Form1::frm1_btn2_Click);
			// 
			// frm1_btn3
			// 
			this->frm1_btn3->Location = System::Drawing::Point(16, 193);
			this->frm1_btn3->Name = L"frm1_btn3";
			this->frm1_btn3->Size = System::Drawing::Size(195, 50);
			this->frm1_btn3->TabIndex = 9;
			this->frm1_btn3->Text = L"���ֹ�������";
			this->frm1_btn3->UseVisualStyleBackColor = true;
			this->frm1_btn3->Click += gcnew System::EventHandler(this, &Form1::frm1_btn3_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button3);
			this->groupBox1->Controls->Add(this->frm1_btn1);
			this->groupBox1->Controls->Add(this->frm1_btn2);
			this->groupBox1->Controls->Add(this->frm1_btn3);
			this->groupBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->groupBox1->Location = System::Drawing::Point(451, 36);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(232, 356);
			this->groupBox1->TabIndex = 10;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"�����׸�";
			this->groupBox1->Enter += gcnew System::EventHandler(this, &Form1::groupBox1_Enter);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(16, 273);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(195, 50);
			this->button3->TabIndex = 10;
			this->button3->Text = L"Ȩ������";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label1->ForeColor = System::Drawing::Color::CadetBlue;
			this->label1->Location = System::Drawing::Point(79, 27);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(233, 29);
			this->label1->TabIndex = 11;
			this->label1->Text = L"EZ Abeek Program";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label2->Location = System::Drawing::Point(56, 68);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(248, 18);
			this->label2->TabIndex = 12;
			this->label2->Text = L"������ ������ IP �ּҸ� �Է��� �ּ���.";
			this->label2->Click += gcnew System::EventHandler(this, &Form1::label2_Click);
			// 
			// linkLabel1
			// 
			this->linkLabel1->AutoSize = true;
			this->linkLabel1->Location = System::Drawing::Point(134, 33);
			this->linkLabel1->Name = L"linkLabel1";
			this->linkLabel1->Size = System::Drawing::Size(47, 18);
			this->linkLabel1->TabIndex = 13;
			this->linkLabel1->TabStop = true;
			this->linkLabel1->Text = L"�۾�ü";
			this->linkLabel1->LinkClicked += gcnew System::Windows::Forms::LinkLabelLinkClickedEventHandler(this, &Form1::linkLabel1_LinkClicked);
			// 
			// linkLabel2
			// 
			this->linkLabel2->AutoSize = true;
			this->linkLabel2->Location = System::Drawing::Point(201, 33);
			this->linkLabel2->Name = L"linkLabel2";
			this->linkLabel2->Size = System::Drawing::Size(60, 18);
			this->linkLabel2->TabIndex = 14;
			this->linkLabel2->TabStop = true;
			this->linkLabel2->Text = L"�۾�����";
			this->linkLabel2->LinkClicked += gcnew System::Windows::Forms::LinkLabelLinkClickedEventHandler(this, &Form1::linkLabel2_LinkClicked);
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(12, 59);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(389, 163);
			this->richTextBox1->TabIndex = 15;
			this->richTextBox1->Text = L"";
			this->richTextBox1->TextChanged += gcnew System::EventHandler(this, &Form1::richTextBox1_TextChanged);
			this->richTextBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Form1::richTextBox1_KeyPress);
			// 
			// groupBox2
			// 
			this->groupBox2->BackColor = System::Drawing::SystemColors::Control;
			this->groupBox2->Controls->Add(this->label4);
			this->groupBox2->Controls->Add(this->linkLabel2);
			this->groupBox2->Controls->Add(this->linkLabel1);
			this->groupBox2->Controls->Add(this->label3);
			this->groupBox2->Controls->Add(this->richTextBox1);
			this->groupBox2->Controls->Add(this->textBox2);
			this->groupBox2->Controls->Add(this->button2);
			this->groupBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->groupBox2->Location = System::Drawing::Point(12, 134);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(418, 258);
			this->groupBox2->TabIndex = 16;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"ä�� ���α׷�";
			this->groupBox2->Enter += gcnew System::EventHandler(this, &Form1::groupBox2_Enter);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(9, 33);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(109, 18);
			this->label4->TabIndex = 17;
			this->label4->Text = L"ä�� �۾�ü ����";
			this->label4->Click += gcnew System::EventHandler(this, &Form1::label4_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(9, 231);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(34, 18);
			this->label3->TabIndex = 16;
			this->label3->Text = L"�Է�";
			this->label3->Click += gcnew System::EventHandler(this, &Form1::label3_Click);
			// 
			// Form1
			// 
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::None;
			this->ClientSize = System::Drawing::Size(733, 404);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->groupBox2);
			this->Name = L"Form1";
			this->Text = L"EZ Abeek Program Client";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->groupBox1->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void groupBox_KeyPress(System::Object^  sender, System::Windows::Forms::KeyPressEventArgs^  e) {
			 }
		 //����� ���� ���� ����
		 public: Socket^ client;
		 public: IPEndPoint^ IP;
		 public: Thread^ clientThread;
//���α׷��� �ε�Ǹ� ����Ǵ� �̺�Ʈ
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 //������ �ʱ�ȭ
			 client = gcnew Socket(AddressFamily::InterNetwork, SocketType::Stream, ProtocolType::IP);
		 }
//������ ������ ����Ǵ� �̺�Ʈ (������ �����ư �̺�Ʈ)
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 //�ش� ������ 2016��Ʈ�� ����
			 try {
			 IP = gcnew IPEndPoint(IPAddress::Parse(textBox1->Text), 2016);
			 client->Connect(IP);

			 // backgroundWorker1 �̺�Ʈ ����
			 backgroundWorker1->RunWorkerAsync();
			 System::Windows::Forms::Button^ frm1_btn1;
			 System::Windows::Forms::Button^ frm1_btn2;
			 System::Windows::Forms::Button^ frm1_btn3;
			 
			 }
			 //������ �߻��� ���
			 catch (Exception^ ex)
			 {
			 MessageBox::Show(ex->Message);
			 }
			 System::Windows::Forms::Button^ frm1_btn1;
			 
		 }
// ��׶���1 �̺�Ʈ ����
private: System::Void backgroundWorker1_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {
			 // ������������ ���� �޽����� �ݺ������� ����
			while (true)
		    {

			// �޽����� ���ۿ� ����
            array<unsigned char>^ buf = gcnew array<unsigned char>(1024);
            int temp = client->Receive(buf);
            FormatterText::StructChat^ str = gcnew FormatterText::StructChat();

            // ���۷� �Ѿ�� �����͸� FomatterText::StructChat ��ü�� str�� ��ȯ�� �ؽ�Ʈ�� ������
            str = Deserialize(buf);
            addText(str->textChat, str->myFont, str->myColor);
            }
		 }
		 // �ؽ�Ʈ�� �߰��ϴ� �Լ� addText()
	     private: void addText(String^ text, System::Drawing::Font^ font, System::Drawing::Color^ color)
         {

         //// ���� �ؽ�Ʈ �ڽ��� �ش� ���ڿ��� ������
          richTextBox1->SelectionFont = font;
          richTextBox1->SelectionColor = (Color)color;
          richTextBox1->AppendText(text + "\n");
          richTextBox1->ScrollToCaret();
          }
		  // MemoryStream�� BinaryFormatter�� �̿��� FormatterText::StructChat�� ���ڿ� ���¸� ���� ���·� ��ȯ�ϰ� �ٽ� ���� ���� �� �� ����
		  public: array<unsigned char, 1>^ Serialize(FormatterText::StructChat^ str)
		  {
	      MemoryStream^ ms = gcnew MemoryStream();
		  BinaryFormatter^ bf = gcnew BinaryFormatter();
		  bf->Serialize(ms, str);
		  return ms->ToArray();
		  }

		  public: FormatterText::StructChat^ Deserialize(array<unsigned char>^ buff)
		  {
		  MemoryStream^ ms = gcnew MemoryStream(buff);
		  BinaryFormatter^ bf = gcnew BinaryFormatter();
		  return (FormatterText::StructChat^)bf->Deserialize(ms);
		  }


private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
		  FormatterText::StructChat^ str = gcnew FormatterText::StructChat();

		  // ������ ���� ���ڿ��� StructChat ��ü ���·� ��ȯ
		  str->textChat = textBox2->Text;
		  str->myColor = textBox2->ForeColor;
		  str->myFont = textBox2->Font;

		  // �ش� StructChat ��ü ���¸� ���۷� ���� �� �ְ� Serialize() �ؼ� ������ ������
		  array<unsigned char>^ buf = gcnew array<unsigned char>(1024);
		  MemoryStream^ ms = gcnew MemoryStream();
		  BinaryFormatter^ bf = gcnew BinaryFormatter();
		  bf->Serialize(ms, str);
		  buf = ms->ToArray();
		  client->Send(buf, buf->Length, SocketFlags::None);

		  textBox2->Text = "";

		  }
private: System::Void frm1_btn1_Click(System::Object^  sender, System::EventArgs^  e) {
			 //this -> Hide();
			 Form2^ f2 = gcnew Form2();
			 f2->ShowDialog();
			 //Application::Exit();
		 }
private: System::Void frm1_btn2_Click(System::Object^  sender, System::EventArgs^  e) {
			 //this -> Hide();
			 Form10^ f10 = gcnew Form10();
			 f10->ShowDialog();
			// Application::Exit();
		 }
private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {

		 }
private: System::Void groupBox1_Enter(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void linkLabel1_LinkClicked(System::Object^  sender, System::Windows::Forms::LinkLabelLinkClickedEventArgs^  e) {
			  if (fontDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			  {
			  // TextBox�� �۾�ü�� ������ �۾�ü�� ����
			  textBox2->Font = fontDialog1->Font;
			  }
		 }
private: System::Void linkLabel2_LinkClicked(System::Object^  sender, System::Windows::Forms::LinkLabelLinkClickedEventArgs^  e) {
			 if (colorDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			 {
			  // TextBox�� �۾� ������ ������ �۾� ����� ����
              textBox2->ForeColor = colorDialog1->Color;
              }
		 }
private: System::Void richTextBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void textBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void frm1_btn3_Click(System::Object^  sender, System::EventArgs^  e) {
			// this -> Hide();
			 Form4^ f4 = gcnew Form4();
			 f4->ShowDialog();
			 //Application::Exit();
		 }
private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void groupBox2_Enter(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label3_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void groupBox3_Enter(System::Object^  sender, System::EventArgs^  e) {
		 }

		 
		 private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
				
		
					  System::Diagnostics::Process^ process = System::Diagnostics::Process::Start("http://dicesku.sungkyul.ac.kr/");


				  }

private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void richTextBox1_KeyPress(System::Object^  sender, System::Windows::Forms::KeyPressEventArgs^  e) {
			 e->Handled=true;
		 }
};
}

