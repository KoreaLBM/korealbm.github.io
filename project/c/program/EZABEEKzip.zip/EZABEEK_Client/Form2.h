#pragma once
#include "Form3.h"
#include <my_global.h>
#include <mysql.h>

namespace EZABEEK_Client {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient; // MySQL ����ϰڴٰ� ǥ��


	/// <summary>
	/// Form2�� ���� ����Դϴ�.
	/// </summary>
	public ref class Form2 : public System::Windows::Forms::Form
	{
	public:
		Form2(void)
		{
			InitializeComponent();
			//
			//TODO: ������ �ڵ带 ���⿡ �߰��մϴ�.
			//
		}

	protected:
		/// <summary>
		/// ��� ���� ��� ���ҽ��� �����մϴ�.
		/// </summary>
		~Form2()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  frm2_btn1;
	protected: 
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label3;

	private:
		/// <summary>
		/// �ʼ� �����̳� �����Դϴ�.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		void InitializeComponent(void)
		{
			this->frm2_btn1 = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// frm2_btn1
			// 
			this->frm2_btn1->Font = (gcnew System::Drawing::Font(L"�������� ExtraBold", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->frm2_btn1->Location = System::Drawing::Point(90, 144);
			this->frm2_btn1->Name = L"frm2_btn1";
			this->frm2_btn1->Size = System::Drawing::Size(81, 40);
			this->frm2_btn1->TabIndex = 9;
			this->frm2_btn1->Text = L"Ȯ��";
			this->frm2_btn1->UseVisualStyleBackColor = true;
			this->frm2_btn1->Click += gcnew System::EventHandler(this, &Form2::frm2_btn1_Click);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(150, 99);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 25);
			this->textBox2->TabIndex = 8;
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(150, 58);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 25);
			this->textBox1->TabIndex = 7;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &Form2::textBox1_TextChanged);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"��������", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label2->Location = System::Drawing::Point(96, 102);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(36, 17);
			this->label2->TabIndex = 6;
			this->label2->Text = L"�й�";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"��������", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label1->Location = System::Drawing::Point(96, 61);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(36, 17);
			this->label1->TabIndex = 5;
			this->label1->Text = L"�г�";
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"�������� ExtraBold", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button1->Location = System::Drawing::Point(197, 144);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(81, 40);
			this->button1->TabIndex = 10;
			this->button1->Text = L"���";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form2::button1_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"�������� ExtraBold", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label3->ForeColor = System::Drawing::Color::CadetBlue;
			this->label3->Location = System::Drawing::Point(49, 15);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(269, 20);
			this->label3->TabIndex = 11;
			this->label3->Text = L"������ �г�� �й��� �Է����ּ���.";
			// 
			// Form2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(355, 205);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->frm2_btn1);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form2";
			this->Text = L"EZ Abeek Program Client";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 if(MessageBox::Show("��������Ͻðڽ��ϱ�?","���α׷�",MessageBoxButtons::YesNo,MessageBoxIcon::Question)==System::Windows::Forms::DialogResult::Yes){
					// Application::Exit();
					 
				 }
			 }
private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {

		 }
private: System::Void frm2_btn1_Click(System::Object^  sender, System::EventArgs^  e) {

			String^ constring=L"datasource=localhost;port=3306;username=root;password=root";
			MySqlConnection^ conDataBase=gcnew MySqlConnection(constring);
			MySqlCommand^ cmdDataBase=gcnew MySqlCommand("select * from stu.stu where grade='"+this->textBox1->Text+"' and class='"+this->textBox2->Text+"';",conDataBase);
			MySqlDataReader^ myReader;
			try{
				conDataBase->Open();
				myReader=cmdDataBase->ExecuteReader();
				int count=0;
				while(myReader->Read()){
					count = count+1;
				}
				if(count==1){
					MessageBox::Show("�ش��й��� �ش��г��� ������ �˻��մϴ�.");
					this->Hide();
					Form3^ f3 = gcnew Form3();
					f3->ShowDialog();
					//Application::Exit();
				}
				else if(count>1){
					MessageBox::Show("�ش��й��� �ش��г��� ����Ͽ����ϴ�.");
				}
				else
					MessageBox::Show("������ �����ϴ�.");
			}catch(Exception^ ex){
				MessageBox::Show(ex->Message);
			}

			

		 }
};
}
