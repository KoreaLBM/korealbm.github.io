#pragma once

namespace EZABEEK_Client {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Form7�� ���� ����Դϴ�.
	/// </summary>
	public ref class Form7 : public System::Windows::Forms::Form
	{
	public:
		Form7(void)
		{
			InitializeComponent();
			//
			//TODO: ������ �ڵ带 ���⿡ �߰��մϴ�.
			//
		}

	protected:
		/// <summary>
		/// ��� ���� ��� ���ҽ��� �����մϴ�.
		/// </summary>
		~Form7()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:
	private: int f_sum;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  button18;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  button17;
	private: System::Windows::Forms::Button^  button16;
	private: System::Windows::Forms::Button^  button15;
	private: System::Windows::Forms::Button^  button14;
	private: System::Windows::Forms::Button^  button13;
	private: System::Windows::Forms::Button^  button12;
	private: System::Windows::Forms::Button^  button11;
	private: System::Windows::Forms::Button^  button10;
	private: System::Windows::Forms::Button^  button9;
	private: System::Windows::Forms::Button^  button8;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Button^  btn_0;
























	protected:

	private:
		/// <summary>
		/// �ʼ� �����̳� �����Դϴ�.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�. 
		/// �� �޼����� ������ �ڵ� ������� �������� ������.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form7::typeid));
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->btn_0 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"����", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label7->Location = System::Drawing::Point(607, 100);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(181, 15);
			this->label7->TabIndex = 58;
			this->label7->Text = L"|-------3�г�------|";
			this->label7->Click += gcnew System::EventHandler(this, &Form7::label7_Click);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"����", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label6->Location = System::Drawing::Point(404, 100);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(181, 15);
			this->label6->TabIndex = 57;
			this->label6->Text = L"|-------2�г�------|";
			this->label6->Click += gcnew System::EventHandler(this, &Form7::label6_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"����", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label5->Location = System::Drawing::Point(201, 100);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(181, 15);
			this->label5->TabIndex = 56;
			this->label5->Text = L"|-------1�г�------|";
			this->label5->Click += gcnew System::EventHandler(this, &Form7::label5_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 19.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label4->ForeColor = System::Drawing::Color::CadetBlue;
			this->label4->Location = System::Drawing::Point(383, 30);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(343, 38);
			this->label4->TabIndex = 54;
			this->label4->Text = L"�̼�ü��/���ļ�����(2015)";
			// 
			// button18
			// 
			this->button18->AutoSize = true;
			this->button18->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->button18->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button18->Location = System::Drawing::Point(705, 469);
			this->button18->Name = L"button18";
			this->button18->Size = System::Drawing::Size(80, 40);
			this->button18->TabIndex = 53;
			this->button18->Text = L"�˰�����";
			this->button18->UseVisualStyleBackColor = false;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label3->Location = System::Drawing::Point(907, 520);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(69, 17);
			this->label3->TabIndex = 52;
			this->label3->Text = L"MSC ����";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label2->Location = System::Drawing::Point(909, 500);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(56, 17);
			this->label2->TabIndex = 51;
			this->label2->Text = L"�������";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label1->Location = System::Drawing::Point(908, 481);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(56, 17);
			this->label1->TabIndex = 50;
			this->label1->Text = L"��������";
			// 
			// button17
			// 
			this->button17->AutoSize = true;
			this->button17->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->button17->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button17->Location = System::Drawing::Point(501, 469);
			this->button17->Name = L"button17";
			this->button17->Size = System::Drawing::Size(79, 40);
			this->button17->TabIndex = 49;
			this->button17->Text = L"��ü����\r\n���α׷���";
			this->button17->UseVisualStyleBackColor = false;
			// 
			// button16
			// 
			this->button16->AutoSize = true;
			this->button16->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->button16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button16->Location = System::Drawing::Point(606, 212);
			this->button16->Name = L"button16";
			this->button16->Size = System::Drawing::Size(79, 40);
			this->button16->TabIndex = 48;
			this->button16->Text = L"����̷�";
			this->button16->UseVisualStyleBackColor = false;
			// 
			// button15
			// 
			this->button15->AutoSize = true;
			this->button15->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->button15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button15->Location = System::Drawing::Point(404, 272);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(79, 40);
			this->button15->TabIndex = 47;
			this->button15->Text = L"����ȸ��";
			this->button15->UseVisualStyleBackColor = false;
			// 
			// button14
			// 
			this->button14->AutoSize = true;
			this->button14->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->button14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button14->Location = System::Drawing::Point(404, 469);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(79, 40);
			this->button14->TabIndex = 46;
			this->button14->Text = L"������\r\n ����";
			this->button14->UseVisualStyleBackColor = false;
			// 
			// button13
			// 
			this->button13->AutoSize = true;
			this->button13->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->button13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button13->Location = System::Drawing::Point(604, 268);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(79, 40);
			this->button13->TabIndex = 45;
			this->button13->Text = L"�Ӻ����\r\n�ý���";
			this->button13->UseVisualStyleBackColor = false;
			// 
			// button12
			// 
			this->button12->AutoSize = true;
			this->button12->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->button12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button12->Location = System::Drawing::Point(501, 218);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(79, 40);
			this->button12->TabIndex = 44;
			this->button12->Text = L"��ǻ��\r\n ����";
			this->button12->UseVisualStyleBackColor = false;
			// 
			// button11
			// 
			this->button11->AutoSize = true;
			this->button11->BackColor = System::Drawing::Color::Yellow;
			this->button11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button11->Location = System::Drawing::Point(607, 469);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(79, 40);
			this->button11->TabIndex = 43;
			this->button11->Text = L"�����\r\n���α׷���";
			this->button11->UseVisualStyleBackColor = false;
			// 
			// button10
			// 
			this->button10->AutoSize = true;
			this->button10->BackColor = System::Drawing::Color::Yellow;
			this->button10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button10->Location = System::Drawing::Point(501, 322);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(79, 40);
			this->button10->TabIndex = 42;
			this->button10->Text = L"����ȸ��\r\n����";
			this->button10->UseVisualStyleBackColor = false;
			// 
			// button9
			// 
			this->button9->AutoSize = true;
			this->button9->BackColor = System::Drawing::Color::Yellow;
			this->button9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button9->Location = System::Drawing::Point(404, 429);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(79, 40);
			this->button9->TabIndex = 41;
			this->button9->Text = L"���α׷���\r\n����";
			this->button9->UseVisualStyleBackColor = false;
			// 
			// button8
			// 
			this->button8->AutoSize = true;
			this->button8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button8->Location = System::Drawing::Point(307, 429);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(79, 40);
			this->button8->TabIndex = 40;
			this->button8->Text = L"���α׷���\r\n���II";
			this->button8->UseVisualStyleBackColor = false;
			// 
			// button3
			// 
			this->button3->AutoSize = true;
			this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button3->Location = System::Drawing::Point(209, 429);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(79, 40);
			this->button3->TabIndex = 39;
			this->button3->Text = L"���α׷���\r\n���I";
			this->button3->UseVisualStyleBackColor = false;
			// 
			// button7
			// 
			this->button7->AutoSize = true;
			this->button7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button7->Location = System::Drawing::Point(307, 272);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(79, 40);
			this->button7->TabIndex = 38;
			this->button7->Text = L" ����\r\n������II";
			this->button7->UseVisualStyleBackColor = false;
			// 
			// button5
			// 
			this->button5->AutoSize = true;
			this->button5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button5->Location = System::Drawing::Point(209, 272);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(79, 40);
			this->button5->TabIndex = 37;
			this->button5->Text = L" ����\r\n������I";
			this->button5->UseVisualStyleBackColor = false;
			// 
			// button4
			// 
			this->button4->AutoSize = true;
			this->button4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button4->Location = System::Drawing::Point(404, 218);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(82, 40);
			this->button4->TabIndex = 36;
			this->button4->Text = L"���� �����";
			this->button4->UseVisualStyleBackColor = false;
			// 
			// button2
			// 
			this->button2->AutoSize = true;
			this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button2->Location = System::Drawing::Point(501, 163);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(79, 40);
			this->button2->TabIndex = 35;
			this->button2->Text = L"��Ű�����\r\n ���� ����";
			this->button2->UseVisualStyleBackColor = false;
			// 
			// button6
			// 
			this->button6->AutoSize = true;
			this->button6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button6->Location = System::Drawing::Point(307, 163);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(78, 40);
			this->button6->TabIndex = 34;
			this->button6->Text = L"�̺й�����";
			this->button6->UseVisualStyleBackColor = false;
			// 
			// button1
			// 
			this->button1->AutoSize = true;
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button1->Location = System::Drawing::Point(212, 163);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(76, 40);
			this->button1->TabIndex = 33;
			this->button1->Text = L"���м���";
			this->button1->UseVisualStyleBackColor = false;
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(196, 128);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(800, 467);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 59;
			this->pictureBox1->TabStop = false;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label8->Location = System::Drawing::Point(908, 540);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(68, 17);
			this->label8->TabIndex = 60;
			this->label8->Text = L"���ļ�����";
			this->label8->Click += gcnew System::EventHandler(this, &Form7::label8_Click);
			// 
			// btn_0
			// 
			this->btn_0->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn_0->Location = System::Drawing::Point(856, 32);
			this->btn_0->Name = L"btn_0";
			this->btn_0->Size = System::Drawing::Size(108, 47);
			this->btn_0->TabIndex = 61;
			this->btn_0->Text = L"���Ȯ��";
			this->btn_0->UseVisualStyleBackColor = true;
			this->btn_0->Click += gcnew System::EventHandler(this, &Form7::btn_0_Click);
			// 
			// Form7
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->ClientSize = System::Drawing::Size(1132, 668);
			this->Controls->Add(this->btn_0);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->button18);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button17);
			this->Controls->Add(this->button16);
			this->Controls->Add(this->button15);
			this->Controls->Add(this->button14);
			this->Controls->Add(this->button13);
			this->Controls->Add(this->button12);
			this->Controls->Add(this->button11);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"Form7";
			this->Text = L"���ļ����� Ȯ�� [2015]";
			this->Load += gcnew System::EventHandler(this, &Form7::Form7_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button18_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label8_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void Form7_Load(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label6_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label7_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label5_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void btn_0_Click(System::Object^  sender, System::EventArgs^  e) {
				 if (f_sum < 8) {
		MessageBox::Show("���������� ��� �������� ���߽��ϴ�. �������� �繫�Ƿ� ���� �ٶ��ϴ�.", "�������� Ȯ�� ���",MessageBoxButtons::OK);
	}
	else
		MessageBox::Show("���������� �������Դϴ�.", "�������� Ȯ�� ���", MessageBoxButtons::OK);
			 }
};
}
