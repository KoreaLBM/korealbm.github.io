#pragma once

namespace EZABEEK_Client {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Form6�� ���� ����Դϴ�.
	/// </summary>
	public ref class Form6 : public System::Windows::Forms::Form
	{
	public:
		Form6(void)
		{
			InitializeComponent();
			//
			//TODO: ������ �ڵ带 ���⿡ �߰��մϴ�.
			//
		}

	protected:
		/// <summary>
		/// ��� ���� ��� ���ҽ��� �����մϴ�.
		/// </summary>
		~Form6()
		{
			if (components)
			{
				delete components;
			}
		}

	private: int f_sum;

	private: System::Windows::Forms::Button^  btn1;
	private: System::Windows::Forms::Button^  btn2;
	private: System::Windows::Forms::Button^  btn3;
	private: System::Windows::Forms::Button^  btn4;
	private: System::Windows::Forms::Button^  btn7;
	private: System::Windows::Forms::Button^  btn8;
	private: System::Windows::Forms::Button^  btn12;
	private: System::Windows::Forms::Button^  btn13;
	private: System::Windows::Forms::Button^  btn14;
	protected:










	private: System::Windows::Forms::Button^  btn11;
	private: System::Windows::Forms::Button^  btn17;



	private: System::Windows::Forms::Button^  btn5;
	private: System::Windows::Forms::Button^  btn10;
	private: System::Windows::Forms::Button^  btn15;




	private: System::Windows::Forms::Button^  btn9;

	private: System::Windows::Forms::Button^  btn6;
	private: System::Windows::Forms::Button^  btn16;



	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  btn18;

	private: System::Windows::Forms::Label^  label4;

	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Button^  btn_0;
	private: System::Windows::Forms::Label^  label8;

	protected:

	private:
		/// <summary>
		/// �ʼ� �����̳� �����Դϴ�.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�. 
		/// �� �޼����� ������ �ڵ� ������� �������� ������.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form6::typeid));
			this->btn1 = (gcnew System::Windows::Forms::Button());
			this->btn2 = (gcnew System::Windows::Forms::Button());
			this->btn3 = (gcnew System::Windows::Forms::Button());
			this->btn4 = (gcnew System::Windows::Forms::Button());
			this->btn7 = (gcnew System::Windows::Forms::Button());
			this->btn8 = (gcnew System::Windows::Forms::Button());
			this->btn12 = (gcnew System::Windows::Forms::Button());
			this->btn13 = (gcnew System::Windows::Forms::Button());
			this->btn14 = (gcnew System::Windows::Forms::Button());
			this->btn11 = (gcnew System::Windows::Forms::Button());
			this->btn17 = (gcnew System::Windows::Forms::Button());
			this->btn5 = (gcnew System::Windows::Forms::Button());
			this->btn10 = (gcnew System::Windows::Forms::Button());
			this->btn15 = (gcnew System::Windows::Forms::Button());
			this->btn9 = (gcnew System::Windows::Forms::Button());
			this->btn6 = (gcnew System::Windows::Forms::Button());
			this->btn16 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->btn18 = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->btn_0 = (gcnew System::Windows::Forms::Button());
			this->label8 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// btn1
			// 
			this->btn1->AutoSize = true;
			this->btn1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->btn1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn1->Location = System::Drawing::Point(196, 153);
			this->btn1->Name = L"btn1";
			this->btn1->Size = System::Drawing::Size(70, 40);
			this->btn1->TabIndex = 1;
			this->btn1->Text = L"���м���";
			this->btn1->UseVisualStyleBackColor = false;
			this->btn1->Click += gcnew System::EventHandler(this, &Form6::btn1_Click);
			// 
			// btn2
			// 
			this->btn2->AutoSize = true;
			this->btn2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			
			this->btn2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn2->Location = System::Drawing::Point(294, 153);
			this->btn2->Name = L"btn2";
			this->btn2->Size = System::Drawing::Size(77, 40);
			this->btn2->TabIndex = 6;
			this->btn2->Enabled = false;
			this->btn2->Text = L"�̺й�����";
			this->btn2->UseVisualStyleBackColor = false;
			this->btn2->Click += gcnew System::EventHandler(this, &Form6::btn2_Click);
			// 
			// btn3
			// 
			this->btn3->AutoSize = true;
			this->btn3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->btn3->Enabled = false;
			this->btn3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn3->Location = System::Drawing::Point(476, 153);
			this->btn3->Name = L"btn3";
			this->btn3->Size = System::Drawing::Size(77, 40);
			this->btn3->TabIndex = 7;
			this->btn3->Text = L"��Ű�����\r\n ���� ����";
			this->btn3->UseVisualStyleBackColor = false;
			this->btn3->Click += gcnew System::EventHandler(this, &Form6::btn3_Click);
			// 
			// btn4
			// 
			this->btn4->AutoSize = true;
			this->btn4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->btn4->Enabled = false;
			this->btn4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn4->Location = System::Drawing::Point(384, 218);
			this->btn4->Name = L"btn4";
			this->btn4->Size = System::Drawing::Size(81, 40);
			this->btn4->TabIndex = 9;
			this->btn4->Text = L"���� �����";
			this->btn4->UseVisualStyleBackColor = false;
			this->btn4->Click += gcnew System::EventHandler(this, &Form6::btn4_Click);
			// 
			// btn7
			// 
			this->btn7->AutoSize = true;
			this->btn7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->btn7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn7->Location = System::Drawing::Point(193, 290);
			this->btn7->Name = L"btn7";
			this->btn7->Size = System::Drawing::Size(73, 40);
			this->btn7->TabIndex = 10;
			this->btn7->Text = L" ����\r\n������I";
			this->btn7->UseVisualStyleBackColor = false;
			this->btn7->Click += gcnew System::EventHandler(this, &Form6::btn7_Click);
			// 
			// btn8
			// 
			this->btn8->AutoSize = true;
			this->btn8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->btn8->Enabled = false;
			this->btn8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn8->Location = System::Drawing::Point(294, 289);
			this->btn8->Name = L"btn8";
			this->btn8->Size = System::Drawing::Size(73, 40);
			this->btn8->TabIndex = 11;
			this->btn8->Text = L" ����\r\n������II";
			this->btn8->UseVisualStyleBackColor = false;
			this->btn8->Click += gcnew System::EventHandler(this, &Form6::btn8_Click);
			// 
			// btn12
			// 
			this->btn12->AutoSize = true;
			this->btn12->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->btn12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn12->Location = System::Drawing::Point(193, 489);
			this->btn12->Name = L"btn12";
			this->btn12->Size = System::Drawing::Size(77, 40);
			this->btn12->TabIndex = 12;
			this->btn12->Text = L"���α׷���\r\n���I";
			this->btn12->UseVisualStyleBackColor = false;
			this->btn12->Click += gcnew System::EventHandler(this, &Form6::btn12_Click);
			// 
			// btn13
			// 
			this->btn13->AutoSize = true;
			this->btn13->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(92)), static_cast<System::Int32>(static_cast<System::Byte>(226)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->btn13->Enabled = false;
			this->btn13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn13->Location = System::Drawing::Point(294, 489);
			this->btn13->Name = L"btn13";
			this->btn13->Size = System::Drawing::Size(77, 40);
			this->btn13->TabIndex = 13;
			this->btn13->Text = L"���α׷���\r\n���II";
			this->btn13->UseVisualStyleBackColor = false;
			this->btn13->Click += gcnew System::EventHandler(this, &Form6::btn13_Click);
			// 
			// btn14
			// 
			this->btn14->AutoSize = true;
			this->btn14->BackColor = System::Drawing::Color::Yellow;
			this->btn14->Enabled = false;
			this->btn14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn14->Location = System::Drawing::Point(384, 489);
			this->btn14->Name = L"btn14";
			this->btn14->Size = System::Drawing::Size(77, 40);
			this->btn14->TabIndex = 14;
			this->btn14->Text = L"���α׷���\r\n����";
			this->btn14->UseVisualStyleBackColor = false;
			this->btn14->Click += gcnew System::EventHandler(this, &Form6::btn14_Click);
			// 
			// btn11
			// 
			this->btn11->AutoSize = true;
			this->btn11->BackColor = System::Drawing::Color::Yellow;
			this->btn11->Enabled = false;
			this->btn11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn11->Location = System::Drawing::Point(476, 355);
			this->btn11->Name = L"btn11";
			this->btn11->Size = System::Drawing::Size(73, 40);
			this->btn11->TabIndex = 15;
			this->btn11->Text = L"����ȸ��\r\n����";
			this->btn11->UseVisualStyleBackColor = false;
			this->btn11->Click += gcnew System::EventHandler(this, &Form6::btn11_Click);
			// 
			// btn17
			// 
			this->btn17->AutoSize = true;
			this->btn17->BackColor = System::Drawing::Color::Yellow;
			this->btn17->Enabled = false;
			this->btn17->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn17->Location = System::Drawing::Point(567, 560);
			this->btn17->Name = L"btn17";
			this->btn17->Size = System::Drawing::Size(77, 40);
			this->btn17->TabIndex = 16;
			this->btn17->Text = L"�����\r\n���α׷���";
			this->btn17->UseVisualStyleBackColor = false;
			this->btn17->Click += gcnew System::EventHandler(this, &Form6::btn17_Click);
			// 
			// btn5
			// 
			this->btn5->AutoSize = true;
			this->btn5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->btn5->Enabled = false;
			this->btn5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn5->Location = System::Drawing::Point(476, 218);
			this->btn5->Name = L"btn5";
			this->btn5->Size = System::Drawing::Size(73, 40);
			this->btn5->TabIndex = 17;
			this->btn5->Text = L"��ǻ��\r\n ����";
			this->btn5->UseVisualStyleBackColor = false;
			this->btn5->Click += gcnew System::EventHandler(this, &Form6::btn5_Click);
			// 
			// btn10
			// 
			this->btn10->AutoSize = true;
			this->btn10->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->btn10->Enabled = false;
			this->btn10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn10->Location = System::Drawing::Point(567, 290);
			this->btn10->Name = L"btn10";
			this->btn10->Size = System::Drawing::Size(73, 40);
			this->btn10->TabIndex = 18;
			this->btn10->Text = L"�Ӻ����\r\n�ý���";
			this->btn10->UseVisualStyleBackColor = false;
			this->btn10->Click += gcnew System::EventHandler(this, &Form6::btn10_Click);
			// 
			// btn15
			// 
			this->btn15->AutoSize = true;
			this->btn15->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->btn15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn15->Location = System::Drawing::Point(384, 560);
			this->btn15->Name = L"btn15";
			this->btn15->Size = System::Drawing::Size(73, 40);
			this->btn15->TabIndex = 19;
			this->btn15->Text = L"������\r\n ����";
			this->btn15->UseVisualStyleBackColor = false;
			this->btn15->Click += gcnew System::EventHandler(this, &Form6::btn15_Click);
			// 
			// btn9
			// 
			this->btn9->AutoSize = true;
			this->btn9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->btn9->Enabled = false;
			this->btn9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn9->Location = System::Drawing::Point(384, 290);
			this->btn9->Name = L"btn9";
			this->btn9->Size = System::Drawing::Size(73, 40);
			this->btn9->TabIndex = 20;
			this->btn9->Text = L"����ȸ��";
			this->btn9->UseVisualStyleBackColor = false;
			this->btn9->Click += gcnew System::EventHandler(this, &Form6::btn9_Click);
			// 
			// btn6
			// 
			this->btn6->AutoSize = true;
			this->btn6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->btn6->Enabled = false;
			this->btn6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn6->Location = System::Drawing::Point(567, 218);
			this->btn6->Name = L"btn6";
			this->btn6->Size = System::Drawing::Size(73, 40);
			this->btn6->TabIndex = 21;
			this->btn6->Text = L"����̷�";
			this->btn6->UseVisualStyleBackColor = false;
			this->btn6->Click += gcnew System::EventHandler(this, &Form6::btn6_Click);
			// 
			// btn16
			// 
			this->btn16->AutoSize = true;
			this->btn16->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->btn16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn16->Location = System::Drawing::Point(476, 560);
			this->btn16->Name = L"btn16";
			this->btn16->Size = System::Drawing::Size(77, 40);
			this->btn16->TabIndex = 22;
			this->btn16->Text = L"��ü����\r\n���α׷���";
			this->btn16->UseVisualStyleBackColor = false;
			this->btn16->Click += gcnew System::EventHandler(this, &Form6::btn16_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label1->Location = System::Drawing::Point(802, 572);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(56, 17);
			this->label1->TabIndex = 23;
			this->label1->Text = L"��������";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label2->Location = System::Drawing::Point(802, 589);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(56, 17);
			this->label2->TabIndex = 24;
			this->label2->Text = L"�������";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label3->Location = System::Drawing::Point(805, 610);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(69, 17);
			this->label3->TabIndex = 25;
			this->label3->Text = L"MSC ����";
			// 
			// btn18
			// 
			this->btn18->AutoSize = true;
			this->btn18->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(217)), static_cast<System::Int32>(static_cast<System::Byte>(217)), 
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->btn18->Enabled = false;
			this->btn18->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn18->Location = System::Drawing::Point(655, 562);
			this->btn18->Name = L"btn18";
			this->btn18->Size = System::Drawing::Size(74, 40);
			this->btn18->TabIndex = 26;
			this->btn18->Text = L"�˰�����";
			this->btn18->UseVisualStyleBackColor = false;
			this->btn18->Click += gcnew System::EventHandler(this, &Form6::btn18_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 19.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label4->ForeColor = System::Drawing::Color::CadetBlue;
			this->label4->Location = System::Drawing::Point(294, 25);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(439, 38);
			this->label4->TabIndex = 27;
			this->label4->Text = L"�̼�ü��/���ļ�����(2013~2015)";
			this->label4->Click += gcnew System::EventHandler(this, &Form6::label4_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"����", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label5->Location = System::Drawing::Point(193, 98);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(199, 15);
			this->label5->TabIndex = 29;
			this->label5->Text = L"|--------1�г�-------|";
			this->label5->Click += gcnew System::EventHandler(this, &Form6::label5_Click);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"����", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label6->Location = System::Drawing::Point(381, 98);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(199, 15);
			this->label6->TabIndex = 30;
			this->label6->Text = L"|--------2�г�-------|";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"����", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label7->Location = System::Drawing::Point(564, 98);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(199, 15);
			this->label7->TabIndex = 31;
			this->label7->Text = L"|--------3�г�-------|";
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(138, 127);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(827, 510);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 33;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &Form6::pictureBox1_Click);
			// 
			// btn_0
			// 
			this->btn_0->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->btn_0->Location = System::Drawing::Point(905, 41);
			this->btn_0->Name = L"btn_0";
			this->btn_0->Size = System::Drawing::Size(108, 47);
			this->btn_0->TabIndex = 34;
			this->btn_0->Text = L"���Ȯ��";
			this->btn_0->UseVisualStyleBackColor = true;
			this->btn_0->Click += gcnew System::EventHandler(this, &Form6::btn_0_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label8->ForeColor = System::Drawing::Color::Red;
			this->label8->Location = System::Drawing::Point(620, 419);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(238, 40);
			this->label8->TabIndex = 35;
			this->label8->Text = L"�� �����Ͻ� ������� ��ư�� �����ּ���\r\n    ex) ���м��� -> ���й�����I";
			// 
			// Form6
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1092, 668);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->btn_0);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->btn18);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btn16);
			this->Controls->Add(this->btn6);
			this->Controls->Add(this->btn9);
			this->Controls->Add(this->btn15);
			this->Controls->Add(this->btn10);
			this->Controls->Add(this->btn5);
			this->Controls->Add(this->btn17);
			this->Controls->Add(this->btn11);
			this->Controls->Add(this->btn14);
			this->Controls->Add(this->btn13);
			this->Controls->Add(this->btn12);
			this->Controls->Add(this->btn8);
			this->Controls->Add(this->btn7);
			this->Controls->Add(this->btn4);
			this->Controls->Add(this->btn3);
			this->Controls->Add(this->btn2);
			this->Controls->Add(this->btn1);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"Form6";
			this->Text = L"���ļ����� Ȯ�� [2013~2015]";
			this->Load += gcnew System::EventHandler(this, &Form6::Form6_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form6_Load(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label5_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void pictureBox1_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void btn1_Click(System::Object^  sender, System::EventArgs^  e) {
	btn2->Enabled = true;
	btn4->Enabled = true;
	btn9->Enabled = true;
	btn1->Enabled = false;
	f_sum = f_sum + 1;
}
private: System::Void btn7_Click(System::Object^  sender, System::EventArgs^  e) {
	btn8->Enabled = true;
	btn11->Enabled = true;
	btn7->Enabled = false;
	f_sum = f_sum + 1;
}
private: System::Void btn12_Click(System::Object^  sender, System::EventArgs^  e) {
	btn14->Enabled = true;
	btn13->Enabled = true;
	btn12->Enabled = false;
	f_sum = f_sum + 1;
}
private: System::Void btn2_Click(System::Object^  sender, System::EventArgs^  e) {
	btn3->Enabled = true;
	btn2->Enabled = false;
	f_sum = f_sum + 1;
}
private: System::Void btn8_Click(System::Object^  sender, System::EventArgs^  e) {
	btn8->Enabled = false;
}
private: System::Void btn13_Click(System::Object^  sender, System::EventArgs^  e) {
	btn13->Enabled = false;
}
private: System::Void btn3_Click(System::Object^  sender, System::EventArgs^  e) {
	btn6->Enabled = true;
	btn3->Enabled = false;
	f_sum = f_sum + 1;
}
private: System::Void btn4_Click(System::Object^  sender, System::EventArgs^  e) {
	btn5->Enabled = true;
	btn4->Enabled = false;
	f_sum = f_sum + 1;
}
private: System::Void btn15_Click(System::Object^  sender, System::EventArgs^  e) {
	btn18->Enabled = true;
	btn15->Enabled = false;
	f_sum = f_sum + 1;
}
private: System::Void btn16_Click(System::Object^  sender, System::EventArgs^  e) {
	btn17->Enabled = true;
	btn16->Enabled = false;
	f_sum = f_sum + 1;
}
private: System::Void btn_0_Click(System::Object^  sender, System::EventArgs^  e) {
	if (f_sum < 8) {
		MessageBox::Show("���������� ��� �������� ���߽��ϴ�. �������� �繫�Ƿ� ���� �ٶ��ϴ�.", "�������� Ȯ�� ���",MessageBoxButtons::OK);
	}
	else
		MessageBox::Show("���������� �������Դϴ�.", "�������� Ȯ�� ���", MessageBoxButtons::OK);
}
private: System::Void btn6_Click(System::Object^  sender, System::EventArgs^  e) {
	btn6->Enabled = false;
}
private: System::Void btn5_Click(System::Object^  sender, System::EventArgs^  e) {
	btn5->Enabled = false;
}
private: System::Void btn10_Click(System::Object^  sender, System::EventArgs^  e) {
	btn10->Enabled = false;
}
private: System::Void btn11_Click(System::Object^  sender, System::EventArgs^  e) {
	btn11->Enabled = false;
}
private: System::Void btn14_Click(System::Object^  sender, System::EventArgs^  e) {
	btn14->Enabled = false;
}
private: System::Void btn17_Click(System::Object^  sender, System::EventArgs^  e) {
	btn17->Enabled = false;
}
private: System::Void btn18_Click(System::Object^  sender, System::EventArgs^  e) {
	btn18->Enabled = false;
}
private: System::Void btn9_Click(System::Object^  sender, System::EventArgs^  e) {
	btn10->Enabled = true;
	btn9->Enabled = false;
}
private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
