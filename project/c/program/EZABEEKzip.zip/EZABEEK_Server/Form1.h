#pragma once

#include <string>

namespace EZABEEK_Server {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace FormatterText;
	using namespace System::Collections::Generic;
	using namespace System::Net;
	using namespace System::Net::Sockets;
	using namespace System::Threading;  //�����尡 �����ϵ��� ��
	using namespace System::IO;
	using namespace System::Runtime::Serialization::Formatters::Binary;
	//using namespace MySql::Data::MySqlClient;
	/// <summary>
	/// Form1�� ���� ����Դϴ�.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: ������ �ڵ带 ���⿡ �߰��մϴ�.
			//
			CheckForIllegalCrossThreadCalls = false; 
		}

	protected:
		/// <summary>
		/// ��� ���� ��� ���ҽ��� �����մϴ�.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  textBox1;
	 
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::RichTextBox^  mainTextBox;
	private: System::ComponentModel::BackgroundWorker^  backgroundWorker1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: static System::Windows::Forms::RichTextBox^  richTextBox1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::Button^  button2;

	private:
		/// <summary>
		/// �ʼ� �����̳� �����Դϴ�.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		void InitializeComponent(void)
		{
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->mainTextBox = (gcnew System::Windows::Forms::RichTextBox());
			this->backgroundWorker1 = (gcnew System::ComponentModel::BackgroundWorker());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(73, 52);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(312, 25);
			this->textBox1->TabIndex = 0;
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"��������", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->button1->Location = System::Drawing::Point(400, 42);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 40);
			this->button1->TabIndex = 1;
			this->button1->Text = L"����";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// mainTextBox
			// 
			this->mainTextBox->Location = System::Drawing::Point(12, 88);
			this->mainTextBox->Name = L"mainTextBox";
			this->mainTextBox->Size = System::Drawing::Size(480, 219);
			this->mainTextBox->TabIndex = 8;
			this->mainTextBox->Text = L"";
			// 
			// backgroundWorker1
			// 
			this->backgroundWorker1->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker1_DoWork);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"��������", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label1->Location = System::Drawing::Point(14, 55);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(53, 17);
			this->label1->TabIndex = 3;
			this->label1->Text = L"IP �ּ�";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"�����ٸ�����", 13.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(129)));
			this->label2->ForeColor = System::Drawing::Color::CadetBlue;
			this->label2->Location = System::Drawing::Point(137, 13);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(210, 27);
			this->label2->TabIndex = 4;
			this->label2->Text = L"EZ Abeek Program";
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(498, 13);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(446, 261);
			this->richTextBox1->TabIndex = 7;
			this->richTextBox1->Text = L"";
			this->richTextBox1->TextChanged += gcnew System::EventHandler(this, &Form1::richTextBox1_TextChanged);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(498, 280);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(368, 25);
			this->textBox2->TabIndex = 6;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(872, 284);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 0;
			this->button2->Text = L"����";
			this->button2->Click += gcnew System::EventHandler(this,&Form1::button2_cilcked);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(956, 319);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->mainTextBox);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBox1);
			this->Name = L"Form1";
			this->Text = L"EZ Abeek Program";
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &Form1::Form1_FormClosing);
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void mainTextBox_KeyPress(System::Object^  sender, System::Windows::Forms::KeyPressEventArgs^  e) {
				 e->Handled = true;
			 }

	public: static Socket^ server;
	public: static List<Socket^>^ listClient = gcnew List<Socket^>();
	public: static IPEndPoint^ IP;
	public: static Thread^ threadClient;

	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 IP = gcnew IPEndPoint(IPAddress::Parse(textBox1->Text), 2016);
				 backgroundWorker1->WorkerSupportsCancellation = true;
				 backgroundWorker1->RunWorkerAsync();
			 }

			 // �ϳ��� Ŭ���̾�Ʈ�� �ٷ�� ������ �Լ�
	private: static void client(Object^ obj)
			 {
				 Socket^ socket = (Socket^)obj;
				 while (true)
				 {
					 try
					 {

						 // Ŭ���̾�Ʈ���Լ� ���۸� ���� �޽����� �Է� ����
						 array<unsigned char>^ buff = gcnew array<unsigned char>(1024);
						 int temp = socket->Receive(buff);
						 FormatterText::StructChat^ str = gcnew FormatterText::StructChat();
			
						 for each(Socket^ sock in listClient)
						 {
							 try {
								 sock->Send(buff, buff->Length, SocketFlags::None);				
							 }
							 catch (Exception^ ex)
							 {
							 }
						 }

						 MemoryStream^ ms = gcnew MemoryStream(buff);
						 BinaryFormatter^ bf = gcnew BinaryFormatter();
						 str = (FormatterText::StructChat^)bf->Deserialize(ms);
						 addTextTorichTextBox1(str->textChat,str->myFont,str->myColor);

					 }
					 // ������ �߻��� ��� �ش� Ŭ���̾�Ʈ ����
					 catch (Exception^ ex)
					 {
						 listClient->Remove(socket);
						 return;
					 }
				 }
			 }

	private: void addTextToMainTextBox(String ^text, System::Drawing::Font^ font, System::Drawing::Color^ color)
			 {
				 mainTextBox->SelectionFont = font;
				 mainTextBox->SelectionColor = (Color) color;
				 mainTextBox->AppendText(text + "\n");
			 }
			 // �ؽ�Ʈ�� �߰��ϴ� �Լ� addText()
	private: static void addTextTorichTextBox1(String^ buff, System::Drawing::Font^ font1, System::Drawing::Color^ color1)
			 {

				 //// ���� �ؽ�Ʈ �ڽ��� �ش� ���ڿ��� ������
				 richTextBox1->SelectionFont = font1;
				 richTextBox1->SelectionColor = (Color)color1;
				 richTextBox1->AppendText(buff + "\n");
				 richTextBox1->ScrollToCaret();
			 }

	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
				 server = gcnew Socket(AddressFamily::InterNetwork, SocketType::Stream, ProtocolType::IP);
				 //���α׷��� ������ �Ǹ� �ڿ������� ���������� �ʱ�ȭ
			 }
	private: System::Void backgroundWorker1_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {
				 // ���� ������ �˸�
				 server->Bind(IP);
				 server->Listen(10);
				 String^ text = "������ �����ϰ� �ֽ��ϴ�.";
				 System::Drawing::Font^ font = gcnew System::Drawing::Font("���� ����", 9, FontStyle::Bold);
				 System::Drawing::Color^ color = Color::Red;
				 addTextToMainTextBox(text, font, color);
				// addTextTorichTextBox1(text, font, color);
				 // ���� �ݺ����� ����ڵ��� ��Ʈ����
				 while (true)
				 {
					 Socket^ clientAccept = server->Accept();
					 listClient->Add(clientAccept);

					 // Ŭ���̾�Ʈ ���� �� �ش� Ŭ���̾�Ʈ���� �����带 �Ҵ��� client �Լ� ����
					 threadClient = gcnew Thread(gcnew ParameterizedThreadStart(EZABEEK_Server::Form1::client));
					 threadClient->IsBackground = true;
					 threadClient->Start(clientAccept);

					 // Ŭ���̾�Ʈ ������ �˸�
					 String^ textTemp = "Ŭ���̾�Ʈ�� �����߽��ϴ�." + clientAccept->RemoteEndPoint->ToString();
					 System::Drawing::Font^ fontTemp = gcnew System::Drawing::Font("���� ����", 9, FontStyle::Bold);
					 System::Drawing::Color^ colorTemp = Color::Red;
					 addTextToMainTextBox(textTemp, fontTemp, colorTemp);
				 }
			 }

	private: System::Void Form1_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
				 if (backgroundWorker1->IsBusy)
				 {
					 backgroundWorker1->CancelAsync();
				 }
			 }

			 private: System::Void button2_cilcked(System::Object^ sender, System::EventArgs^ e) {

				 String^ str_send = "[������] : " + textBox2->Text ;
				 
				 addTextTorichTextBox1(str_send, textBox2->Font, textBox2->ForeColor);

				 FormatterText::StructChat^ str = gcnew FormatterText::StructChat();
				 
				 str->textChat = str_send;
				 str->myColor = textBox2->ForeColor;
				 str->myFont = textBox2->Font;

				 array<unsigned char>^ buf = gcnew array<unsigned char>(1024);
				 MemoryStream^ ms = gcnew MemoryStream();
				 BinaryFormatter^ bf = gcnew BinaryFormatter();
				 bf->Serialize(ms, str);
				 buf = ms->ToArray();

				 for each (Socket^ sock in listClient)
				 {
					 try {
						 sock->Send(buf, buf->Length, SocketFlags::None);
					 }
					 catch (Exception^ ex)
					 {
					 }
				 }

				 textBox2->Text = "";
			 }


private: System::Void richTextBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

